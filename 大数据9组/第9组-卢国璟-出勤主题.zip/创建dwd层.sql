
create database if not exists edu_dwd;
drop table if exists class_studying_student_count_dwd;
create table if not exists class_studying_student_count_dwd(
id int comment'part of primary id',
school_id int comment'校区id',
subject_id int comment'学科id',
class_id int comment'班级id',
studying_student_count int comment'在读班级人数',
studying_date string comment'在读日期'
)
comment'班级在读人数dwd'
partitioned by(dt string)
row format delimited
fields terminated by'\t'
stored as orc
tblproperties('orc.compress'='SNAPPY');

-------------------------------------------------------------------------------------------------------------------
drop table if exists course_table_upload_detail_dwd;
create table if not exists course_table_upload_detail_dwd(
        id int comment'part of primary id',
        base_id int comment'课程主表id',
        class_id int comment'班级id',
        class_date string comment'上课日期',
        content STRING comment'课程内容',
        teacher_id int comment'教师id',
        teacher_name STRING comment'教师姓名',
        job_number STRING comment'工号',
        classroom_id int comment'教室id',
        classroom_name string comment'教室名称',
        is_outline int comment'是否大纲 0否 1是',
        class_mode int
        comment'上课模式 0传统全天 1上午 2下午 3线上直播',
        is_stage_exam int comment'是否阶段考试 0:否 1:是',
        is_pay int comment'代课费',
        tutor_teacher_id int comment'晚修辅导老师id',
        tutor_teacher_name STRING comment'辅导老师姓名',
        tutor_job_number STRING comment'晚修辅导老师工号',
        is_subsidy int comment'晚自习补贴 0:无 1:有',
        answer_teacher_id int comment'答疑老师id',
        answer_teacher_name string comment'答疑老师姓名',
        answer_job_number STRING comment'答疑老师工号',
        remark STRING comment'备注',
        create_time string comment'创建时间')
comment'班级课表dwd'
partitioned by(dt string)
row format delimited
fields terminated by'\t'
stored as orc
tblproperties('orc.compress'='SNAPPY');
-----------------------------------------------------------------------------------------------------
drop table if exists student_leave_apply_dwd;
create table if not exists student_leave_apply_dwd(
            	id int,
	class_id int comment'班级id',
	student_id int comment'学员id',
	audit_state int comment'审核状态 0待审核 1通过 2不通过',
	audit_person int comment'审核人',
	audit_time string comment'审核时间',
	audit_remark string comment'审核备注',
	leave_type int comment'请假类型 1请假 2销假',
	leave_reason int comment'请假原因 1事假 2病假',
	begin_time string comment'请假开始时间',
	begin_time_type int comment'1上午 2下午',
	end_time string comment'请假结束时间',
	end_time_type int comment'1上午 2下午',
	days decimal(5,1) comment'请假、已休天数',
	cancel_state int comment'撤销状态 0未撤销 1已撤销',
	cancel_time string comment'撤销时间',
	old_leave_id int comment'原请假id只有leave——id =2 才有',
	leave_remark string comment'请假说明',
	valid_state int comment'是否有效 0无效 1有效',
	create_time string comment'创建时间'
)
comment'学生请假申请dwd'
partitioned by(dt string)
row format delimited
fields terminated by'\t'
stored as orc
tblproperties('orc.compress'='SNAPPY');

---------------------------------------------------------------------------------
create table if not exists tbh_class_time_table_dwd(
    id int,
    class_id int comment'班级id',
    morning_template_id int comment'上午出勤模板id',
        morning_begin_time string comment'上午开始时间',
        morning_end_time string comment'上午结束时间',
        afternoon_template_id int comment'下午出勤模板id',
        afternoon_begin_time string comment'下午开始时间',
        afternoon_end_time string comment'下午结束时间',
        evening_template_id int comment'晚上出勤模板id',
        evening_begin_time string comment'晚上开始时间',
        evening_end_time string comment'晚上结束时间',
        use_begin_date string comment'使用开始日期',
        use_end_date string comment'使用结束日期',
        create_time string comment'创建时间',
        create_person string comment'创建人',
        remark string comment'备注',
        morning_begin_clock int comment'上午签到开始时间戳',
        morning_end_clock int comment'上午签到结束时间戳',
        afternoon_begin_clock int comment'下午签到开始时间戳',
        afternoon_end_clock int comment'下午签到结束时间戳',
        evening_begin_clock int comment'晚上签到开始时间戳',
        evening_end_clock int comment'晚上签到结束时间戳'
)
comment'班级作息时间dwd'
partitioned by(dt string)
row format delimited
fields terminated by'\t'
stored as orc
tblproperties('orc.compress'='SNAPPY');
-------------------------------------------------------------------------------------
drop table if exists tbh_student_signin_record_dwd;
create table if not exists tbh_student_signin_record_dwd(
     id int comment'id',
        normal_class_flag int COMMENT'是否正课1正课，2自习' ,
        time_table_id int
        COMMENT'作息时间表id关联tbh_schooltime_table或者tbh_class_time_table',
        class_id INT COMMENT'班级id',
        student_id int comment'学员id',
        signin_time string comment'签到时间',
        signin_date string comment'签到日期',
        inner_flag int comment'内外网标志 0 外网 1内网',
        signin_type int comment'签到类型 1心跳打卡 2老师补卡',
        share_state int comment'共享屏幕状态',
        inner_ip STRING comment'内网ip地址',
        signing_timesamp int comment'打卡点的时间戳'
)
comment'学生打卡dwd'
partitioned by(dt string)
row format delimited
fields terminated by'\t'
stored as orc
tblproperties('orc.compress'='SNAPPY');