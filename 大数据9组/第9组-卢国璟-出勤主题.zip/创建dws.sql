CREATE DATABASE edu_dws;
use edu_dws;
CREATE TABLE  attendance_finally(
    class_id int,
    student_id int,
    class_date string,
    studying_student_count int,
    on_timel string,
    late string,
     leave string,
     days string,
     months string,
     years string,
    time_type string
)

 comment '请假宽表'
PARTITIONED BY (dt string)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
stored as orc
TBLPROPERTIES ('orc.compress'='SNAPPY');