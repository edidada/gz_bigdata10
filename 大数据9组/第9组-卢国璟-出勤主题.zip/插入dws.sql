--开启动态分区
set hive.exec.dynamic.partition = true;
--开启非严格模式
set hive.exec.dynamic.partition.mode =nonstrict;
-- 开启mapjoin
set hive.auto.convert.join=true;
-- 写入数据强制分桶
set hive.enforce.bucketing=true;
-- 写入数据强制排序
set hive.enforce.sorting=true;
-- 开启bucketmapjoin
set hive.optimize.bucketmapjoin = true;
-- 开启SMB Join
set hive.optimize.bucketmapjoin.sortedmerge=true;
set hive.auto.convert.sortmerge.join=true;
set hive.auto.convert.sortmerge.join.noconditionaltask=true;
with student_attendance as
    (select

        class_id,
        class_date,
        studying_student_count,
        student_id,
        studying_date,
        substring(studying_date,1,4) as years,
        substring(studying_date,1,7) as months,
        substring(studying_date,1,10) as days,
        max(morning_type) over (partition by student_id,dt) as morning_type_sum,
        max(afternoon_type) over (partition by student_id,dt) as afternoon_type_sum,
        max(evening_type) over (partition by student_id,dt) as evening_type_sum,
        row_number() over(partition by student_id,dt) as rn,
        dt
    from attendance_dwm) ,
  --个人请假
    leave as
    (
    select
        class_id,
        class_date,
        studying_student_count,
        student_id,
        studying_date,
        substring(studying_date,1,4) as years,
        substring(studying_date,1,7) as months,
        substring(studying_date,1,10) as days,
        max(morning_leave) over (partition by student_id,dt) as morning_leave_sum,
        max(afternoon_leave) over (partition by student_id,dt) as afternoon_leave_sum,
        max(evening_leave) over (partition by student_id,dt) as evening_leave_sum,
        row_number() over(partition by student_id,dt) as rn2,
        dt
    from leave_apply_dwm),
   class_attendance as (
        select
            class_id,
            class_date,
            studying_student_count,
            student_id,
            substring(studying_date,1,4) as years,
            substring(studying_date,1,7) as months,
            substring(studying_date,1,10) as days,
            if (morning_type_sum='1','1','0') as on_time,
            if (morning_type_sum='2','1','0') as late ,
            '0' as leave,
            'morning_attendance' as time_type,
            dt
        from student_attendance
        where rn = 1
        union
   select
       class_id,--行列拼接

--学生个人
with student_attendance as
    (select

        class_id,
        class_date,
        studying_student_count,
        student_id,
        studying_date,
        substring(studying_date,1,4) as years,
        substring(studying_date,1,7) as months,
        substring(studying_date,1,10) as days,
        max(morning_type) over (partition by student_id,dt) as morning_type_sum,
        max(afternoon_type) over (partition by student_id,dt) as afternoon_type_sum,
        max(evening_type) over (partition by student_id,dt) as evening_type_sum,
        row_number() over(partition by student_id,dt) as rn,
        dt
    from attendance_dwm) ,
  --个人请假
    leave as
    (
    select
        class_id,
        class_date,
        studying_student_count,
        student_id,
        studying_date,
        substring(studying_date,1,4) as years,
        substring(studying_date,1,7) as months,
        substring(studying_date,1,10) as days,
        max(morning_leave) over (partition by student_id,dt) as morning_leave_sum,
        max(afternoon_leave) over (partition by student_id,dt) as afternoon_leave_sum,
        max(evening_leave) over (partition by student_id,dt) as evening_leave_sum,
        row_number() over(partition by student_id,dt) as rn2,
        dt
    from leave_apply_dwm),
   class_attendance as (
        select
            class_id,
            class_date,
            studying_student_count,
            student_id,
            substring(studying_date,1,4) as years,
            substring(studying_date,1,7) as months,
            substring(studying_date,1,10) as days,
            if (morning_type_sum='1','1','0') as on_time,
            if (morning_type_sum='2','1','0') as late ,
            '0' as leave,
            'morning_attendance' as time_type,
            dt
        from student_attendance
        where rn = 1
        union
   select
       class_id,
        class_date,
        studying_student_count,
        student_id,
        substring (studying_date,1,4) as years,
        substring (studying_date,1,7) as months,
        substring (studying_date,1,10) as days,
        if (afternoon_type_sum='1','1','0') as on_time,
        if (afternoon_type_sum='2','1','0') as late ,
        '0' as leave,
        'afternoon_attendance' as time_type,
        dt
    from student_attendance
        where rn = 1
        union
    select
       class_id,
        class_date,
        studying_student_count,
        student_id,
        substring (studying_date,1,4) as years,
        substring (studying_date,1,7) as months,
        substring (studying_date,1,10) as days,
        if (evening_type_sum='1','1','0') as on_time,
        if (evening_type_sum='2','1','0') as late ,
        '0' as leave,
        'evening_attendance' as time_type,
        dt
    from student_attendance
        where rn = 1
        union
     select
        class_id,
        class_date,
        studying_student_count,
        student_id,
        substring (studying_date,1,4) as years,
        substring (studying_date,1,7) as months,
        substring (studying_date,1,10) as days,
        '0' as on_time,
        '0' as late ,
        if(morning_leave_sum='1','1','0') as leave,
        'morning_attendance' as time_type,
        dt
     from leave
        where rn2 = 1
        union
    select
        class_id,
        class_date,
        studying_student_count,
        student_id,
        substring (studying_date,1,4) as years,
        substring (studying_date,1,7) as months,
        substring (studying_date,1,10) as days,
        '0' as on_time,
        '0' as late ,
        if(afternoon_leave_sum='1','1','0') as leave,
        'afternoon_attendance' as time_type,
        dt
     from leave
        where rn2 = 1
        union
    select
        class_id,
        class_date,
        studying_student_count,
        student_id,
        substring (studying_date,1,4) as years,
        substring (studying_date,1,7) as months,
        substring (studying_date,1,10) as days,
        '0' as on_time,
        '0' as late ,
        if(evening_leave_sum='1','1','0') as leave,
        'evening_attendance' as time_type,
        dt
     from leave
        where rn2 = 1
   )insert into edu_dws.attendance_finally partition(dt)
select
    class_id,
    student_id,
    max(class_date) as class_date,
    max(studying_student_count) as studying_student_count,
    max(on_time) as on_time,
    max(late) as late,
    max(leave) as leave,
    days,
    months,
    years,
    time_type,
    dt
    from class_attendance
    group by student_id, class_id, days, months, years, time_type,dt;