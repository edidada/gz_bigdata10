with class_studying_student_count_dwd_tmp as(
select
    a.id,
    a.school_id,
    a.subject_id,
    a.class_id,
    a.studying_student_count,
    a.studying_date,
    a.dt
from edu_ods.class_studying_student_count_ods a)
insert into class_studying_student_count_dwd partition (dt)
select *
from class_studying_student_count_dwd_tmp;

-----------------------------------------------------------------------------------------------------
with course_table_upload as
(select
        a.id ,
        a.base_id ,
        a.class_id ,
        a.class_date ,
        a.content ,
        a.teacher_id ,
        a.teacher_name ,
        a.job_number ,
        a.classroom_id ,
        a.classroom_name ,
        a.is_outline ,
        a.class_mode ,
        a.is_stage_exam ,
        a.is_pay ,
        a.tutor_teacher_id ,
        a.tutor_teacher_name ,
        a.tutor_job_number ,
        a.is_subsidy ,
        a.answer_teacher_id ,
        a.answer_teacher_name ,
        a.answer_job_number ,
        a.remark ,
        a.create_time,
        a.dt
from edu_ods.course_table_upload_detail_ods a)
insert into course_table_upload_detail_dwd partition(dt)
select *
from course_table_upload;
select *
from course_table_upload_detail_dwd;

---------------------------------------------------------------------------------------------------------

with leave_apply as
(
select
    a.id ,
	a.class_id ,
	a.student_id ,
	a.audit_state ,
	a.audit_person ,
	a.audit_time ,
	a.audit_remark,
	a.leave_type ,
	a.leave_reason ,
	a.begin_time ,
	a.begin_time_type ,
	a.end_time ,
	a.end_time_type ,
	a.days ,
	a.cancel_state ,
	a.cancel_time ,
	a.old_leave_id ,
	a.leave_remark ,
	a.valid_state ,
	a.create_time ,
	a.dt
from edu_ods.student_leave_apply_ods a)
insert into student_leave_apply_dwd partition(dt)
select *
from leave_apply;
------------------------------------------------------------------------------------------
with class_table as
(
select
        a.id ,
        a.class_id ,
        a.morning_template_id ,
        a.morning_begin_time ,
        a.morning_end_time ,
        a.afternoon_template_id ,
        a.afternoon_begin_time ,
        a.afternoon_end_time ,
        a.evening_template_id ,
        a.evening_begin_time ,
        a.evening_end_time ,
        a.use_begin_date ,
        a.use_end_date ,
        a.create_time ,
        a.create_person ,
        a.remark ,
       unix_timestamp(a.morning_begin_time,'HH:mm:ss')-2400 as morning_begin_clock ,
        unix_timestamp(a.morning_begin_time,'HH:mm:ss')+600 as morning_end_clock ,
        unix_timestamp(a.afternoon_begin_time,'HH:mm:ss')-2400 as afternoon_begin_clock ,
        unix_timestamp(a.afternoon_begin_time,'HH:mm:ss')+600 as afternoon_end_clock ,
        unix_timestamp(a.evening_begin_time,'HH:mm:ss')-2400 as evening_begin_clock ,
        unix_timestamp(a.evening_begin_time,'HH:mm:ss')+600 as evening_end_clock ,
       a.dt
from edu_ods.tbh_class_time_table_ods a
)
insert into tbh_class_time_table_dwd partition(dt)
select *
from class_table;
----------------------------------------------------------------------------------------------------
with student_sigin_record as
(
select
        a.id ,
        a.normal_class_flag ,
        a.time_table_id ,
        a.class_id ,
        a.student_id ,
        a.signin_time ,
        a.signin_date ,
        a.inner_flag ,
        a.signin_type ,
        a.share_state ,
        a.inner_ip ,
        unix_timestamp(substr(a.signin_time,12,8),'HH:mm:ss') as signing_timesamp,
       --unix_timestamp(a.morning_begin_time,'HH:mm:ss')-2400 as morning_begin_clock ,
       -- unix_timestamp(a.morning_begin_time,'HH:mm:ss')+600 as morning_end_clock ,
       -- unix_timestamp(a.afternoon_begin_time,'HH:mm:ss')-2400 as afternoon_begin_clock ,
       -- unix_timestamp(a.afternoon_begin_time,'HH:mm:ss')+600 as afternoon_end_clock ,
       -- unix_timestamp(a.evening_begin_time,'HH:mm:ss')-2400 as evening_begin_clock ,
       -- unix_timestamp(a.evening_begin_time,'HH:mm:ss')+600 as evening_end_clock ,
       a.dt
from edu_ods.tbh_student_signin_record_ods a
)
insert into tbh_student_signin_record_dwd partition(dt)
select *
from student_sigin_record;