--请假宽表插入
with leave_apply_tmp as (
select
    a.id ,
    a.class_id ,
    a.student_id ,
    a.audit_state ,
    a.audit_person ,
    a.audit_time ,
    a.audit_remark ,
    a.leave_type ,
    a.leave_reason ,
    a.begin_time ,
    a.begin_time_type ,
    a.end_time ,
    a.end_time_type ,
    a.days ,
    a.cancel_state ,
    a.cancel_time ,
    a.old_leave_id ,
    a.leave_remark ,
    a.valid_state ,
    a.create_time ,
    b.morning_template_id ,
    b.morning_begin_time ,
    b.morning_end_time ,
    b.afternoon_template_id ,
    b.afternoon_begin_time ,
    b.afternoon_end_time ,
    b.evening_template_id ,
    b.evening_begin_time ,
    b.evening_end_time ,
    b.use_begin_date ,
    b.use_end_date ,
   b.create_person ,
   b.remark as class_time_table_remark,
   b.morning_begin_clock ,
   b.morning_end_clock ,
   b.afternoon_begin_clock ,
   b.afternoon_end_clock ,
   b.evening_begin_clock ,
   b.evening_end_clock ,
    c.base_id ,
    c.class_date ,
    c.content ,
    c.teacher_id ,
    c.teacher_name ,
    c.job_number ,
    c.classroom_id ,
    c.classroom_name ,
    c.is_outline ,
    c.class_mode ,
    c.is_stage_exam ,
    c.is_pay ,
    c.tutor_teacher_id ,
    c.tutor_teacher_name ,
    c.tutor_job_number ,
    c.is_subsidy ,
    c.answer_teacher_id ,
    c.answer_teacher_name ,
    c.answer_job_number ,
    c.remark ,
    d.school_id ,
    d.subject_id ,

    d.studying_student_count ,
    d.studying_date ,
    case
            when morning_begin_time>=substr(begin_time,12,8) and morning_end_time<=substr(end_time,12,8)
            then '1'
            else '0'
        end
            as morning_leave,
        case
            when afternoon_begin_time>=substr(begin_time,12,8) and afternoon_end_time<=substr(end_time,12,8)
            then '1'
            else '0'
        end
            as afternoon_leave,
        case
            when evening_begin_time>=substr(begin_time,12,8) and evening_end_time<=substr(end_time,12,8)
            then '1'
            else '0'
        end
            as evening_leave,
    c.dt
from edu_dwd.course_table_upload_detail_dwd as c
left join
edu_dwd.student_leave_apply_dwd as a
on a.class_id=c.class_id
left join edu_dwd.tbh_class_time_table_dwd as b
on (c.class_id =b.class_id)
left join edu_dwd.class_studying_student_count_dwd as d
on d.class_id =c.class_id
where (substring (a.begin_time,12,8)<=c.class_date)
and (substring (a.end_time,12,8)>=c.class_date) and ( b.morning_begin_time between substring(a.begin_time,12,8)
and substring(a.end_time,12,8))

)
insert into edu_dwm.leave_apply_dwm partition(dt)
select *
from leave_apply_tmp
where classroom_id is not null ;
--hive 里面不相等的条件不能用on 得放最底下用where
--------------------------------------------------------------------------------------------------------------------
----出勤宽表
with attendance_tmp as (
select
        a.id ,
        a.normal_class_flag ,
        a.time_table_id ,
        a.class_id ,
        a.student_id ,
        a.signin_time ,
        a.signin_date ,
        a.inner_flag ,
        a.signin_type ,
        a.share_state ,
        a.inner_ip ,
        a.signing_timesamp ,
        b.morning_template_id ,
        b.morning_begin_time ,
        b.morning_end_time ,
        b.afternoon_template_id ,
        b.afternoon_begin_time ,
        b.afternoon_end_time ,
        b.evening_template_id ,
        b.evening_begin_time ,
        b.evening_end_time ,
        b.use_begin_date ,
        b.use_end_date ,
        b.create_time as class_time_table_create_time ,
        b.create_person ,
        b.remark as class_table_remark ,
        b.morning_begin_clock ,
        b.morning_end_clock ,
        b.afternoon_begin_clock ,
        b.afternoon_end_clock ,
        b.evening_begin_clock ,
        b.evening_end_clock ,
    c.base_id ,
    c.class_date ,
    c.content ,
    c.teacher_id ,
    c.teacher_name ,
    c.job_number ,
    c.classroom_id ,
    c.classroom_name ,
    c.is_outline ,
    c.class_mode ,
    c.is_stage_exam ,
    c.is_pay ,
    c.tutor_teacher_id ,
    c.tutor_teacher_name ,
    c.tutor_job_number ,
    c.is_subsidy ,
    c.answer_teacher_id ,
    c.answer_teacher_name ,
    c.answer_job_number ,
    c.remark as upload_detail_remark ,
    c.create_time as upload_detail_create_time ,
    d.school_id ,
    d.subject_id ,
    d.studying_student_count ,
    d.studying_date ,
    -- 1正常 2 迟到
   case
       when
       (a.signing_timesamp between  b.morning_begin_clock and b.morning_end_clock)
       then
       1
       when
       (a.signing_timesamp between b.morning_end_clock and unix_timestamp(b.morning_end_time,'HH:mm:ss'))
       then
       2
       else
       0
   end
   as morning_type,
   case
       when
       (a.signing_timesamp
        between  b.afternoon_begin_clock and b.afternoon_end_clock)
       then
       1
       when
       (a.signing_timesamp
        between  b.afternoon_end_clock and unix_timestamp(b.afternoon_end_time,'HH:mm:ss') )
       then
       2
     else
     0
    end
    as afternoon_type,
    case
     when
        (a.signing_timesamp between  b.evening_begin_clock and b.evening_end_clock)

    then 1
     when
    (a.signing_timesamp between  b.evening_end_clock and unix_timestamp(b.evening_end_time,'HH:mm:ss'))
    then 2
     else
        0
    end
    as evening_type,
    a.dt
from edu_dwd.course_table_upload_detail_dwd c
left join  edu_dwd.tbh_class_time_table_dwd b
on  (c.class_id=b.class_id)

left join edu_dwd.tbh_student_signin_record_dwd as a
on (a.class_id=c.class_id) and (a.signin_date=c.class_date)
left join edu_dwd.class_studying_student_count_dwd d
on (c.class_id=d.class_id) and (c.class_date=d.studying_date)
where (b.use_begin_date<=c.class_date)
and ( b.use_end_date>=c.class_date)and (a.time_table_id=b.id)and (a.normal_class_flag=1)
)insert into edu_dwm.attendance_dwm partition(dt)
select  *
from attendance_tmp
where class_id is not null ;