-- 建库
create database edu_dws;

-- 按小时统计，意向线索主题
-- 建表
CREATE TABLE IF NOT EXISTS edu_dws.customer_intention
(
   customer_total        bigint    comment '聚合意向客户数',
   clue_nums             bigint    comment '根据id聚合有效线索数',
   area                  string    comment '区域信息',
   itcast_school_id      int       comment '校区id',
   itcast_school_name    string    comment '校区名称',
   origin_type           string    comment '来源渠道',
   itcast_subject_id     int       comment '学科id',
   itcast_subject_name   string    comment '学科名称',
   hourinfo              string    comment '小时信息',
   origin_type_state     string    comment '数据来源:0.线下；1.线上',
   clue_state_state      string    comment '客户属性：0.老客户；1.新客户',
--   clue_appeal_state     string    comment '是否有效线索: 2有效 1无效',
--   phone                 string    comment '联系方式',
   tdepart_id            int       comment '创建者部门id',
   tdepart_name          string    comment '咨询中心名称',
   group_type            string    comment '产品属性类别：1.区域信息；2.校区信息；3.学科信息；4.来源渠道；5.咨询中心；6.总累计值；',
   yearinfo              string    comment '年',
   monthinfo             string    comment '月',
   dayinfo               string    comment '日'
)
comment '客户意向量DWS表'
PARTITIONED BY(dt string)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
stored as orc
TBLPROPERTIES ('orc.compress'='SNAPPY');


-- 统计每小时 线上线下 新老用户 的总意向量 与 有效线索量
insert into edu_dws.customer_intention
select
    count(distinct customer_id) as customer_total,
    count(if(
             appeal_status is null,
             -- and phone is not null and phone != ' ',
             customer_id,
             null)
    ) as clue_nums,
    area,
    itcast_school_id,
    itcast_school_name,
    origin_type,
    itcast_subject_id,
    itcast_subject_name,
    hourinfo,
    origin_type_state,
    clue_state_state,
    tdepart_id,
    tdepart_name,
    case
        when grouping(area)=0
        then 'area'
        when grouping(itcast_subject_id)=0
        then 'itcast_subject'
        when grouping(itcast_school_id)=0
        then 'itcast_school'
        when grouping(origin_type)=0
        then 'origin_type'
        when grouping(tdepart_id)=0
        then 'tdepart'
        else 'all'
    end
    as group_type,
    yearinfo,
    monthinfo,
    dayinfo,
    '2022-08-13' as dt
from edu_dwb.customer_intention
where clue_state_state in ('new_customer','old_customer')
group by
grouping sets(
    -- 小时 + 线上线下 + 新老用户 + 总
    (yearinfo,monthinfo,dayinfo,hourinfo,origin_type_state,clue_state_state),
    -- 小时 + 线上线下 + 新老用户 + 地区
    (yearinfo,monthinfo,dayinfo,hourinfo,origin_type_state,clue_state_state,area),
    -- 小时 + 线上线下 + 新老用户 + 学科
    (yearinfo,monthinfo,dayinfo,hourinfo,origin_type_state,clue_state_state,itcast_subject_id,itcast_subject_name),
    -- 小时 + 线上线下 + 新老用户 + 校区
    (yearinfo,monthinfo,dayinfo,hourinfo,origin_type_state,clue_state_state,itcast_school_id,itcast_school_name),
    -- 小时 + 线上线下 + 新老用户 + 来源渠道
    (yearinfo,monthinfo,dayinfo,hourinfo,origin_type_state,clue_state_state,origin_type),
    -- 小时 + 线上线下 + 新老用户 + 各咨询中心
    (yearinfo,monthinfo,dayinfo,hourinfo,origin_type_state,clue_state_state,tdepart_id,tdepart_name)
);