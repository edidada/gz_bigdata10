-- 建库
create database edu_dwb;

-- 客户意向DWB表
-- 8表关联，将所有需求字段获取（实际工作中获取全字段，除非确定后期不需要用到）
CREATE TABLE IF NOT EXISTS edu_dwb.customer_intention
(
    customer_id           int      comment  '所属客户id',
    create_date_time      string   comment  '创建时间',
    area                  string   comment  '所在区域',
    itcast_school_id      int      comment  '校区Id',
    itcast_school_name    string   comment  '校区名称',
    origin_type           string   comment  '来源渠道',
    itcast_subject_id     int      comment  '学科ID',
    itcast_subject_name   string   comment  '学科名称',
    hourinfo              string   comment  '小时',
    origin_type_state     string   comment  '数据来源:0 线上  1线下',
    clue_state_state      string   comment  '新老客户:  0 老  1 新',
    appeal_status         int      comment  '是否有效线索: 2有效 1无效',
    tdepart_id            int      comment  '直属部门id',
    tdepart_name          string   comment  '咨询中心名称',
    -- msg_count             int      comment  '客户发送消息数',
    yearinfo              string   comment  '年',
    monthinfo             string   comment  '月',
    dayinfo               string   comment  '日'
)
comment '客户关系DWB表'
PARTITIONED BY(dt string)
clustered by(customer_id) sorted by(customer_id) into 10 buckets
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
stored as orc
TBLPROPERTIES ('orc.compress'='SNAPPY');


--分区
SET hive.exec.dynamic.partition=true;
SET hive.exec.dynamic.partition.mode=nonstrict;
set hive.exec.max.dynamic.partitions.pernode=10000;
set hive.exec.max.dynamic.partitions=100000;
set hive.exec.max.created.files=150000;
--hive压缩
set hive.exec.compress.intermediate=true;
set hive.exec.compress.output=true;
--写入时压缩生效
set hive.exec.orc.compression.strategy=COMPRESSION;
--分桶
set hive.enforce.bucketing=true;
set hive.enforce.sorting=true;

-- 关掉所有的mapjoin优化（避免内存溢出）
set hive.auto.convert.join=false;
set hive.optimize.bucketmapjoin=false;
set hive.auto.convert.sortmerge.join=false;
set hive.optimize.bucketmapjoin.sortedmerge=false;
set hive.auto.convert.sortmerge.join.noconditionaltask=false;


insert into table edu_dwb.customer_intention partition(dt)
select
    cr.customer_id,
    cr.create_date_time,
    c.area,
    cr.itcast_school_id,
    sch.name as itcast_school_name,
    cr.origin_type,
    cr.itcast_subject_id,
    sub.name as itcast_subject_name,
    cr.hourinfo,
    cr.origin_type_state,
    cc.clue_state_state,
    ca.appeal_status,
    e.tdepart_id,
    dep.name as tdepart_name,
    -- ems.msg_count,
    cr.yearinfo,
    cr.monthinfo,
    cr.dayinfo,
    cr.dt
    -- 客户意向表
from edu_dwd.customer_relationship cr
    -- 客户线索表
    left join edu_dwd.customer_clue cc
    on cc.customer_relationship_id = cr.id
    -- 线索申诉表
    left join edu_ods.customer_appeal ca
    on cr.id = ca.customer_relationship_first_id
    -- 客户静态信息表
    left join edu_ods.customer c
    on cr.customer_id = c.id
    -- 学科表
    left join edu_ods.itcast_subject sub
    on cr.itcast_subject_id = sub.id
    -- 校区表
    left join edu_ods.itcast_school sch
    on cr.itcast_school_id = sch.id
    -- 员工表
    left join edu_ods.employee e
    on cr.creator = e.id
    -- 部门表
    left join edu_ods.scrm_department dep
    on e.tdepart_id = dep.id
;