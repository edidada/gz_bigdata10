-- 建库
create database edu_dm;

-- 意向线索主题-数据集市
-- 建表
CREATE TABLE IF NOT EXISTS edu_dm.customer_intention
(
   customer_total        bigint    comment '聚合意向客户数',
   clue_nums             bigint    comment '根据id聚合有效线索数',
   area                  string    comment '区域信息',
   itcast_school_id      int       comment '校区id',
   itcast_school_name    string    comment '校区名称',
   origin_type           string    comment '来源渠道',
   itcast_subject_id     int       comment '学科id',
   itcast_subject_name   string    comment '学科名称',
   origin_type_state     string    comment '数据来源:0.线下；1.线上',
   clue_state_state      string    comment '客户属性：0.老客户；1.新客户',
   tdepart_id            int       comment '创建者部门id',
   tdepart_name          string    comment '咨询中心名称',
   group_type            string    comment '产品属性类别：1.区域信息；2.校区信息；3.学科信息；4.来源渠道；5.咨询中心；6.总累计值；',
   time_type             string    comment '按照哪个时间来统计: 1.小时; 2.天; 3.月; 4.年',
   time_str              string    comment '聚合时间, 便于查询具体时间内容',
   hourinfo              string    comment '小时信息',
   yearinfo              string    comment '年',
   monthinfo             string    comment '月',
   dayinfo               string    comment '日'
)
comment '客户意向DM表'
PARTITIONED BY(dt string)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
stored as orc
TBLPROPERTIES ('orc.compress'='SNAPPY');


insert into edu_dm.customer_intention
with group_by as(
    select
        sum(coalesce(customer_total,0)) as customer_total,
        sum(coalesce(clue_nums,0)) as clue_nums,
        area,
        itcast_school_id,
        itcast_school_name,
        origin_type,
        itcast_subject_id,
        itcast_subject_name,
        origin_type_state,
        clue_state_state,
        tdepart_id,
        tdepart_name,
        case
            when grouping(area)=0
            then 'area'
            when grouping(itcast_subject_id)=0
            then 'itcast_subject'
            when grouping(itcast_school_id)=0
            then 'itcast_school'
            when grouping(origin_type)=0
            then 'origin_type'
            when grouping(tdepart_id)=0
            then 'tdepart'
            else 'all'
        end
        as group_type_dm,
        group_type as group_type_dws,
        case
            when grouping(hourinfo)=0
            then 'hour'
            when grouping(dayinfo)=0
            then 'day'
            when grouping(monthinfo)=0
            then 'month'
            when grouping(yearinfo)=0
            then 'year'
        end
        as time_type,
        case
            when grouping(hourinfo)=0
            then concat(yearinfo,'-',monthinfo,'-',dayinfo,' ',hourinfo)
            when grouping(dayinfo)=0
            then concat(yearinfo,'-',monthinfo,'-',dayinfo)
            when grouping(monthinfo)=0
            then concat(yearinfo,'-',monthinfo)
            when grouping(yearinfo)=0
            then yearinfo
        end
        as time_str,
        hourinfo,
        yearinfo,
        monthinfo,
        dayinfo,
        '2022-08-13' as dt
    from edu_dws.customer_intention
    group by
    grouping sets(
        -- 按年统计
        (yearinfo,origin_type_state,clue_state_state,group_type),
        (yearinfo,origin_type_state,clue_state_state,area,group_type),
        (yearinfo,origin_type_state,clue_state_state,itcast_subject_id,itcast_subject_name,group_type),
        (yearinfo,origin_type_state,clue_state_state,itcast_school_id,itcast_school_name,group_type),
        (yearinfo,origin_type_state,clue_state_state,origin_type,group_type),
        (yearinfo,origin_type_state,clue_state_state,tdepart_id,tdepart_name,group_type),
        -- 按月统计
        (monthinfo,yearinfo,origin_type_state,clue_state_state,group_type),
        (monthinfo,yearinfo,origin_type_state,clue_state_state,area,group_type),
        (monthinfo,yearinfo,origin_type_state,clue_state_state,itcast_subject_id,itcast_subject_name,group_type),
        (monthinfo,yearinfo,origin_type_state,clue_state_state,itcast_school_id,itcast_school_name,group_type),
        (monthinfo,yearinfo,origin_type_state,clue_state_state,origin_type,group_type),
        (monthinfo,yearinfo,origin_type_state,clue_state_state,tdepart_id,tdepart_name,group_type),
        -- 按日统计
        (dayinfo,monthinfo,yearinfo,origin_type_state,clue_state_state,group_type),
        (dayinfo,monthinfo,yearinfo,origin_type_state,clue_state_state,area,group_type),
        (dayinfo,monthinfo,yearinfo,origin_type_state,clue_state_state,itcast_subject_id,itcast_subject_name,group_type),
        (dayinfo,monthinfo,yearinfo,origin_type_state,clue_state_state,itcast_school_id,itcast_school_name,group_type),
        (dayinfo,monthinfo,yearinfo,origin_type_state,clue_state_state,origin_type,group_type),
        (dayinfo,monthinfo,yearinfo,origin_type_state,clue_state_state,tdepart_id,tdepart_name,group_type),
        -- 按小时统计
        (hourinfo,dayinfo,monthinfo,yearinfo,origin_type_state,clue_state_state,group_type),
        (hourinfo,dayinfo,monthinfo,yearinfo,origin_type_state,clue_state_state,area,group_type),
        (hourinfo,dayinfo,monthinfo,yearinfo,origin_type_state,clue_state_state,itcast_subject_id,itcast_subject_name,group_type),
        (hourinfo,dayinfo,monthinfo,yearinfo,origin_type_state,clue_state_state,itcast_school_id,itcast_school_name,group_type),
        (hourinfo,dayinfo,monthinfo,yearinfo,origin_type_state,clue_state_state,origin_type,group_type),
        (hourinfo,dayinfo,monthinfo,yearinfo,origin_type_state,clue_state_state,tdepart_id,tdepart_name,group_type)
    )
)
select
    customer_total,
    clue_nums,
    area,
    itcast_school_id,
    itcast_school_name,
    origin_type,
    itcast_subject_id,
    itcast_subject_name,
    origin_type_state,
    clue_state_state,
    tdepart_id,
    tdepart_name,
    group_type_dm as group_type,
    time_type,
    time_str,
    hourinfo,
    yearinfo,
    monthinfo,
    dayinfo,
    dt
from group_by
where group_type_dm = group_type_dws;

