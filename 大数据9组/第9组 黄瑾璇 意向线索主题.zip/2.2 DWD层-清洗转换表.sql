CREATE TABLE IF NOT EXISTS edu_dwd.customer_relationship
(
    id                            int         comment '客户关系id',
    create_date_time              string      comment '创建时间',
    update_date_time              string      comment '最后更新时间',
    deleted                       int         comment '是否被删除（禁用）',
    customer_id                   int         comment '所属客户id',
    first_id                      int         comment '第一条客户关系id',
    belonger                      int         comment '归属人',
    belonger_name                 string      comment '归属人姓名',
    initial_belonger              int         comment '初始归属人',
    distribution_handler          int         comment '分配处理人',
    business_scrm_department_id   int         comment '归属部门',
    last_visit_time               string      comment '最后回访时间',
    next_visit_time               string      comment '下次回访时间',
    origin_type                   string      comment '数据来源',
    itcast_school_id              int         comment '校区Id',
    itcast_subject_id             int         comment '学科Id',
    intention_study_type          string      comment '意向学习方式',
    anticipat_signup_date         string      comment '预计报名时间',
    level                         string      comment '客户级别',
    creator                       int         comment '创建人',
    current_creator               int         comment '当前创建人：初始==创建人，当在公海拉回时为 拉回人',
    creator_name                  string      comment '创建者姓名',
    origin_channel                string      comment '来源渠道',
    `comment`                     string      comment '备注',
    first_customer_clue_id        int         comment '第一条线索id',
    last_customer_clue_id         int         comment '最后一条线索id',
    process_state                 string      comment '处理状态',
    process_time                  string      comment '处理状态变动时间',
    payment_state                 string      comment '支付状态',
    payment_time                  string      comment '支付状态变动时间',
    signup_state                  string      comment '报名状态',
    signup_time                   string      comment '报名时间',
    notice_state                  string      comment '通知状态',
    notice_time                   string      comment '通知状态变动时间',
    lock_state                    string      comment '锁定状态',
    lock_time                     string      comment '锁定状态修改时间',
    itcast_clazz_id               int         comment '所属ems班级id',
    itcast_clazz_time             string      comment '报班时间',
    payment_url                   string      comment '付款链接',
    payment_url_time              string      comment '支付链接生成时间',
    ems_student_id                int         comment 'ems的学生id',
    delete_reason                 string      comment '删除原因',
    deleter                       int         comment '删除人',
    deleter_name                  string      comment '删除人姓名',
    delete_time                   string      comment '删除时间',
    course_id                     int         comment '课程ID',
    course_name                   string      comment '课程名称',
    delete_comment                string      comment '删除原因说明',
    close_state                   string      comment '关闭装填',
    close_time                    string      comment '关闭状态变动时间',
    appeal_id                     int         comment '申诉id',
    tenant                        int         comment '租户',
    total_fee                     DECIMAL     comment '报名费总金额',
    belonged                      int         comment '小周期归属人',
    belonged_time                 string      comment '归属时间',
    belonger_time                 string      comment '归属时间',
    transfer                      int         comment '转移人',
    transfer_time                 string      comment '转移时间',
    follow_type                   int         comment '分配类型，0-自动分配，1-手动分配，2-自动转移，3-手动单个转移，4-手动批量转移，5-公海领取',
    transfer_bxg_oa_account       string      comment '转移到博学谷归属人OA账号',
    transfer_bxg_belonger_name    string      comment '转移到博学谷归属人OA姓名',
    hourinfo                      string      comment '小时',
    origin_type_state             string         comment '线上线下标识:0 线上  1线下',
    yearinfo                      string      comment '年',
    monthinfo                     string      comment '月',
    dayinfo                       string      comment '日'
)
comment '客户意向表'
PARTITIONED BY(dt string)
clustered by(id) sorted by(id) into 10 buckets
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
stored as orc
TBLPROPERTIES ('orc.compress'='SNAPPY');


--分区
SET hive.exec.dynamic.partition=true;
SET hive.exec.dynamic.partition.mode=nonstrict;
set hive.exec.max.dynamic.partitions.pernode=10000;
set hive.exec.max.dynamic.partitions=100000;
set hive.exec.max.created.files=150000;
--hive压缩
set hive.exec.compress.intermediate=true;
set hive.exec.compress.output=true;
--写入时压缩生效
set hive.exec.orc.compression.strategy=COMPRESSION;
--分桶
set hive.enforce.bucketing=true;
set hive.enforce.sorting=true;


-- 清洗转换--客户意向表
-- 1.学科id与校区id转换
-- 2.线上线下维度转换origin_type
-- 3.时间维度转换create_date_time
insert into table edu_dwd.customer_relationship partition(dt)
select
    id,
    create_date_time,
    update_date_time,
    deleted,
    customer_id,
    first_id,
    belonger,
    belonger_name,
    initial_belonger,
    distribution_handler,
    business_scrm_department_id,
    last_visit_time,
    next_visit_time,
    origin_type,
    -- 此处有转换，将校区id为null或为0的值转换为-1
    if(itcast_school_id is null or itcast_school_id = 0,
        -1,
        itcast_school_id
    ) as itcast_school_id,
    -- 此处有转换，将学科id为null或为0的值转换为-1
    if(itcast_subject_id is null or itcast_subject_id = 0,
        -1,
        itcast_subject_id
    ) as itcast_subject_id,
    intention_study_type,
    anticipat_signup_date,
    level,
    creator,
    current_creator,
    creator_name,
    origin_channel,
    `comment`,
    first_customer_clue_id,
    last_customer_clue_id,
    process_state,
    process_time,
    payment_state,
    payment_time,
    signup_state,
    signup_time,
    notice_state,
    notice_time,
    lock_state,
    lock_time,
    itcast_clazz_id,
    itcast_clazz_time,
    payment_url,
    payment_url_time,
    ems_student_id,
    delete_reason,
    deleter,
    deleter_name,
    delete_time,
    course_id,
    course_name,
    delete_comment,
    close_state,
    close_time,
    appeal_id,
    tenant,
    total_fee,
    belonged,
    belonged_time,
    belonger_time,
    transfer,
    transfer_time,
    follow_type,
    transfer_bxg_oa_account,
    transfer_bxg_belonger_name,
    substr(create_date_time,12,2) as hourinfo,
    -- 此处有转换-线上线下，如果为'NETSERVICE', 'PRESIGNUP'则为线上，其他为线下
    if(origin_type in('NETSERVICE', 'PRESIGNUP'), 'online', 'offline') as origin_type_state,
    substr(create_date_time,1,4) as yearinfo,
    substr(create_date_time,6,2) as monthinfo,
    substr(create_date_time,9,2) as dayinfo,
    start_time as dt
from edu_dwd.customer_relationship_1
where deleted = 0;

select * from edu_dwd.customer_relationship;

-- 遇到问题：分区过多导致内存溢出
-- select
--     substr(create_date_time,1,4) as yearinfo,
--     substr(create_date_time,6,2) as monthinfo,
--     substr(create_date_time,9,2) as dayinfo
-- from edu_dwd.customer_relationship_1
-- group by substr(create_date_time,1,4),
--          substr(create_date_time,6,2),
--          substr(create_date_time,9,2);


CREATE TABLE IF NOT EXISTS edu_dwd.customer_clue
(
    id                          int       COMMENT 'customer_clue_id',
    create_date_time            string    COMMENT '创建时间',
    update_date_time            string    COMMENT '最后更新时间',
    deleted                     string    COMMENT '是否被删除（禁用）',
    customer_id                 int       COMMENT '客户id',
    customer_relationship_id    int       COMMENT '客户关系id',
    session_id                  string    COMMENT '七陌会话id',
    sid                         string    COMMENT '访客id',
    status                      string    COMMENT '状态（undeal待领取 deal 已领取 finish 已关闭 changePeer 已流转）',
    `user`                      string    COMMENT '所属坐席',
    create_time                 string    COMMENT '七陌创建时间',
    platform                    string    COMMENT '平台来源 （pc-网站咨询|wap-wap咨询|sdk-app咨询|weixin-微信咨询）',
    s_name                      string    COMMENT '用户名称',
    seo_source                  string    COMMENT '搜索来源',
    seo_keywords                string    COMMENT '关键字',
    ip                          string    COMMENT 'IP地址',
    referrer                    string    COMMENT '上级来源页面',
    from_url                    string    COMMENT '会话来源页面',
    landing_page_url            string    COMMENT '访客着陆页面',
    url_title                   string    COMMENT '咨询页面title',
    to_peer                     string    COMMENT '所属技能组',
    manual_time                 string    COMMENT '人工开始时间',
    begin_time                  string    COMMENT '坐席领取时间 ',
    reply_msg_count             int       COMMENT '客服回复消息数',
    total_msg_count             int       COMMENT '消息总数',
    msg_count                   int       COMMENT '客户发送消息数',
    `comment`                   string    COMMENT '备注',
    finish_reason               string    COMMENT '结束类型',
    finish_user                 string    COMMENT '结束坐席',
    end_time                    string    COMMENT '会话结束时间',
    platform_description        string    COMMENT '客户平台信息',
    browser_name                string    COMMENT '浏览器名称',
    os_info                     string    COMMENT '系统名称',
    area                        string    COMMENT '区域',
    country                     string    COMMENT '所在国家',
    province                    string    COMMENT '省',
    city                        string    COMMENT '城市',
    creator                     int       COMMENT '创建人',
    name                        string    COMMENT '客户姓名',
    idcard                      string    COMMENT '身份证号',
    phone                       string    COMMENT '手机号',
    itcast_school_id            int       COMMENT '校区Id',
    itcast_school               string    COMMENT '校区',
    itcast_subject_id           int       COMMENT '学科Id',
    itcast_subject              string    COMMENT '学科',
    wechat                      string    COMMENT '微信',
    qq                          string    COMMENT 'qq号',
    email                       string    COMMENT '邮箱',
    gender                      string    COMMENT '性别',
    level                       string    COMMENT '客户级别',
    origin_type                 string    COMMENT '数据来源渠道',
    information_way             string    COMMENT '资讯方式',
    working_years               string    COMMENT '开始工作时间',
    technical_directions        string    COMMENT '技术方向',
    customer_state              string    COMMENT '当前客户状态',
    valid                       string    COMMENT '该线索是否是网资有效线索',
    anticipat_signup_date       string    COMMENT '预计报名时间',
    clue_state                  string    COMMENT '线索状态',
    scrm_department_id          int       COMMENT 'SCRM内部部门id',
    superior_url                string    COMMENT '诸葛获取上级页面URL',
    superior_source             string    COMMENT '诸葛获取上级页面URL标题',
    landing_url                 string    COMMENT '诸葛获取着陆页面URL',
    landing_source              string    COMMENT '诸葛获取着陆页面URL来源',
    info_url                    string    COMMENT '诸葛获取留咨页URL',
    info_source                 string    COMMENT '诸葛获取留咨页URL标题',
    origin_channel              string    COMMENT '投放渠道',
    course_id                   int       COMMENT '课程编号',
    course_name                 string    COMMENT '课程名称',
    zhuge_session_id            string    COMMENT 'zhuge会话id',
    is_repeat                   int       COMMENT '是否重复线索(手机号维度) 0:正常 1：重复',
    tenant                      int       COMMENT '租户id',
    activity_id                 string    COMMENT '活动id',
    activity_name               string    COMMENT '活动名称',
    follow_type                 int       COMMENT '分配类型，0-自动分配，1-手动分配，2-自动转移，3-手动单个转移，4-手动批量转移，5-公海领取',
    shunt_mode_id               int       COMMENT '匹配到的技能组id',
    shunt_employee_group_id     int       COMMENT '所属分流员工组',
    hourinfo                    string    comment '小时',
    clue_state_state            string       COMMENT '新老客户:  0 新  1 老'
)
comment '客户线索表'
PARTITIONED BY(yearinfo string,monthinfo string,dayinfo string)
clustered by(customer_relationship_id) sorted by(customer_relationship_id) into 10 buckets
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
stored as orc
TBLPROPERTIES ('orc.compress'='SNAPPY');


-- 清洗转换--客户线索表
-- 1.学科id与校区id转换
-- 2.新老维度转换clue_state
-- 3.时间维度转换create_date_time
insert into table edu_dwd.customer_clue partition (yearinfo,monthinfo,dayinfo)
select
    id,
    create_date_time,
    update_date_time,
    deleted,
    customer_id,
    customer_relationship_id,
    session_id,
    sid,
    status,
    `user`,
    create_time,
    platform,
    s_name,
    seo_source,
    seo_keywords,
    ip,
    referrer,
    from_url,
    landing_page_url,
    url_title,
    to_peer,
    manual_time,
    begin_time,
    reply_msg_count,
    total_msg_count,
    msg_count,
    `comment`,
    finish_reason,
    finish_user,
    end_time,
    platform_description,
    browser_name,
    os_info,
    area,
    country,
    province,
    city,
    creator,
    name,
    idcard,
    phone,
    -- 此处有转换，将校区id为null或为0的值转换为-1
    if(itcast_school_id is null or itcast_school_id = 0,
        -1,
        itcast_school_id
    ) as itcast_school_id,
    itcast_school,
    -- 此处有转换，将学科id为null或为0的值转换为-1
    if(itcast_subject_id is null or itcast_subject_id = 0,
        -1,
        itcast_subject_id
    ) as itcast_subject_id,
    itcast_subject,
    wechat,
    qq,
    email,
    gender,
    level,
    origin_type,
    information_way,
    working_years,
    technical_directions,
    customer_state,
    valid,
    anticipat_signup_date,
    clue_state,
    scrm_department_id,
    superior_url,
    superior_source,
    landing_url,
    landing_source,
    info_url,
    info_source,
    origin_channel,
    course_id,
    course_name,
    zhuge_session_id,
    is_repeat,
    tenant,
    activity_id,
    activity_name,
    follow_type,
    shunt_mode_id,
    shunt_employee_group_id,
    substr(create_date_time,12,2) as hourinfo,
    -- 此处有转换-新老客户，'VALID_PUBLIC_NEW_CLUE'为老客户，'VALID_NEW_CLUES'为新客户，其余为无效客户
    case
        when clue_state = 'VALID_NEW_CLUES'
        then 'new_customer'
        when clue_state = 'VALID_PUBLIC_NEW_CLUE'
        then 'old_customer'
        else 'other_customer'
    end
    as clue_state_state,
    substr(create_date_time,1,4) as yearinfo,
    substr(create_date_time,6,2) as monthinfo,
    substr(create_date_time,9,2) as dayinfo
from edu_dwd.customer_clue_1
where deleted = 0
and clue_state in ('VALID_NEW_CLUES','VALID_PUBLIC_NEW_CLUE');
